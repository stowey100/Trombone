<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BrokerTransferController extends Controller
{
    //
}
